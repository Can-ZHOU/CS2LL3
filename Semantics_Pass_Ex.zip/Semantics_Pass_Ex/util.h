#include <vector>
#include <string>
using namespace std;

vector<string> tokenize(string line);
